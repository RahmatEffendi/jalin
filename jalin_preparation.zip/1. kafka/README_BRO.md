# PERSIAPAN KAFKA BROKER
========================
1. Deploy kafka broker pada docker
1.1 persiapkan file deployment yaml (cek folder `1. broker`)
1.2 sesuaikan environment, network, port dan volumes
1.3 jalankan docker compose dengan perintah `docker compose up -d`
1.4 pastikan container running
1.5 cek log container `docker logs -f <container-name> --tail 100`

dokumentasi: https://docs.confluent.io/platform/current/installation/docker/config-reference.html#cp-kafka-example

# PERSIAPAN KAFKA CONTROL CENTER (UI)
=====================================
1. Deployment Kafka Control Center (Dari Confluent)
1.1 persiapkan file yaml untuk deployment ke docker
1.2 cek file cp-control-center.yml
1.3 sesuaikan environment, network, port dan volumes
1.4 jalankan perintah `docker compose -f cp-control-center.yml up -d` untuk deploy ke docker
1.5 pastikan container running
1.6 cek log `docker logs -f <container-name> --tail 100`

dokumentasi: https://docs.confluent.io/platform/current/installation/docker/config-reference.html#c3-configuration

2. Deployment Kafka UI (dari provectuslabs)
2.1 persiapkan file yaml untuk deployment ke docker
2.2 cek file provectuslabs-kafka-ui.yml
2.3 sesuaikan environment, network, port dan volumes
2.4 jalankan perintah `provectuslabs-kafka-ui.yml up -d` untuk deploy ke docker
2.5 pastikan container running
2.6 cek log `docker logs -f <container-name> --tail 100`

dokumentasi: https://github.com/provectus/kafka-ui/blob/master/documentation/compose/kafka-ui.yaml https://docs.kafka-ui.provectus.io/