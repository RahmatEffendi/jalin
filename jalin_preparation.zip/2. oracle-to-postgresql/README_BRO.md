# PERSIAPAN DATABASE ORACLE
===========================
1. Instalasi Oracle di docker (opsional)
1.1 persiapkan docker-compose.yml (cek folder oracle-db)
1.2 sesuaikan environment username dan password pada docker compose
1.3 sesuaikan port dan network pada docker compose 
1.4 jalankan docker compose dengan perintah `docker compose up -d`
1.5 pastikan container running
1.6 cek log container `docker logs -f <container-name> --tail 100`

dokumentasi: https://container-registry.oracle.com/ords/f?p=113:4:13785695499113:::4:P4_REPOSITORY,AI_REPOSITORY,AI_REPOSITORY_NAME,P4_REPOSITORY_NAME,P4_EULA_ID,P4_BUSINESS_AREA_ID:803,803,Oracle%20Database%20Express%20Edition,Oracle%20Database%20Express%20Edition,1,0&cs=3IAA5IplxqLjRMbEtjK2lhPhJmpnGw4SHQ00C97c7yefCrgGewby3YeUOWwU7Vkbla3ZvXWlFKFGeE-fvZG83Rg

2. Konfigurasi Database Oracle, agar bisa melakukan change data capture
1.1 cek file ./oracle-db/debezium-oracle-config.sql
1.2 jalankan perintah per baris
1.3 dokumentasi: https://debezium.io/documentation/reference/connectors/oracle.html

# PERSIAPAN KONEKTOR
====================
1. Kafka Connect / Debezium Connector
1.1 persiapkan file yaml untuk deployment konektor ke docker
1.2 cek file debezium-connect.yml
1.3 sesuaikan environment, network, port dan volumes
1.4 jalankan perintah `docker compose -f debezium-connect.yml up -d` untuk deploy konektor
1.5 pastikan container running
1.6 cek log `docker logs -f <container-name> --tail 100`

dokumentasi: https://hub.docker.com/r/debezium/connect
catatan: 1 deployment konektor bisa untuk berbagai integrasi db sperti (postgre,oracle,mariadb,mysql,mongodb,dll)

2. Setup Konektor (Source)
2.1 Buka confluent platform pada browser, yang sebelumnya sudah di deploy.
2.2 Buka halaman Connect/Kafka Connect
2.3 Upload file json `connector_oracle-source-connector_config.json`
2.4 Save & Running
2.5 Pastikan tidak error

dokumentasi: https://debezium.io/documentation/reference/connectors/oracle.html#oracle-example-configuration

3. Setup Konektor (Sink)
2.1 Buka confluent platform pada browser, yang sebelumnya sudah di deploy.
2.2 Buka halaman Connect/Kafka Connect
2.3 Upload file json `connector_postgre_sink_connector_config.json`
2.4 Save & Running
2.5 Pastikan tidak error

dokumentasi: https://debezium.io/documentation/reference/connectors/jdbc.html#jdbc-connector-configuration

# TESTING
=========
1. Lakukan operasi Insert/Update/Delete data pada db oracle
2. Cek Message pada Kafka UI
3. Cek data pada db postgresql