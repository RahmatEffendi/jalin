-- DOCS: https://debezium.io/documentation/reference/connectors/oracle.html#schemas-that-the-debezium-oracle-connector-excludes-when-capturing-change-events

-- masuk container oracle
docker exec -it oracle /bin/bash

-- SETTING REDO LOG SIZE
sqlplus sys/top_secret AS SYSDBA;
SELECT group#, member FROM v$logfile;
-- cek status redolog
SELECT group#, status FROM v$log;
-- hapus redolog yang inactive
-- ALTER DATABASE DROP LOGFILE GROUP group#;
ALTER DATABASE DROP LOGFILE GROUP 1;

-- BUAT REDOLOG BARU DENGAN SIZE MIN. 500MB
ALTER DATABASE ADD LOGFILE GROUP 4 ('/opt/oracle/oradata/XE/redo04.log') SIZE 500M;
ALTER DATABASE ADD LOGFILE GROUP 5 ('/opt/oracle/oradata/XE/redo05.log') SIZE 500M;
ALTER DATABASE ADD LOGFILE GROUP 6 ('/opt/oracle/oradata/XE/redo06.log') SIZE 500M;

-- cek kembali group dan status redolog, ulangi hingga semua redolog yang inactive telah dihapus
-- jika tersisa 1 file redolog dengan size 200MB, maka lanjut ke step berikutnya

-- lakukan berulang, sambil mengecek kembali yang inactive, lalu hapus redolog yang inactive yang berukuran 200 MB
ALTER SYSTEM SWITCH LOGFILE;
SELECT group#, status FROM v$log;
-- apabila redolog 1 masih belum inactive, tambahkan saja 1 GROUP lagi
exit;

-- ENABLE ARCHIVE LOG MODE
sqlplus sys/top_secret AS SYSDBA;

-- recovery : Fast Recovery Area (FRA) Oracle Database
mkdir -p /opt/oracle/oradata/recovery_area
SHOW PARAMETER db_recovery_file_dest_size;
SHOW PARAMETER db_recovery_file_dest;
alter system set db_recovery_file_dest_size = 100G;
alter system set db_recovery_file_dest = '/opt/oracle/oradata/recovery_area' scope=spfile;
shu immediate;
startup;
SHOW PARAMETER db_recovery_file_dest;

-- archive log
select name, open_mode from v$database;
archive log list;
-- SKIP THIS QUERY WHEN ARCHIVE LOG MODE IS ACTIVATED --
  shu immediate;
  startup mount;
  alter database archivelog;
  alter database open;
  shu immediate;
  startup;
  archive log list;
-- /SKIP THIS QUERY WHEN ARCHIVE LOG MODE IS ACTIVATED --
exit;
--


-- ENABLBE SUPPLEMENTAL LOGGING
sqlplus sys/password@localhost:1521/XEPDB1 as sysdba;

-- SUPPLEMENTAL LOG DATA (ALL) COLUMNS
-- Mengaktifkan pencatatan tambahan untuk semua kolom tabel 
-- akan meningkatkan volume log pengulangan Oracle. 
-- Untuk mencegah pertumbuhan ukuran log yang berlebihan, 
-- terapkan konfigurasi sebelumnya secara selektif.
-- ALTER TABLE <SCHEMA>.<TABLE_NAME> ADD SUPPLEMENTAL LOG DATA (ALL) COLUMNS;
DROP TABLE CDC_EXAMPLE.CUSTOMERS;
DROP USER CDC_EXAMPLE CASCADE; 
CREATE USER CDC_EXAMPLE IDENTIFIED BY password;
GRANT CONNECT, RESOURCE TO CDC_EXAMPLE;
CREATE TABLE CDC_EXAMPLE.CUSTOMERS(ID NUMBER(9) NOT NULL ENABLE, FIRST_NAME VARCHAR2(255), LAST_NAME VARCHAR2(255), EMAIL VARCHAR2(255),PRIMARY KEY (ID) ENABLE);
GRANT UNLIMITED TABLESPACE TO CDC_EXAMPLE;
ALTER USER CDC_EXAMPLE QUOTA UNLIMITED ON USERS;
ALTER TABLE CDC_EXAMPLE.CUSTOMERS ADD SUPPLEMENTAL LOG DATA (ALL) COLUMNS;
-- Enable Minimal supplemental logging at the database level
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA;
-- if ERROR at line 1: ORA-31541: Supplemental logging is not enabled in CDB$ROOT.
-- then enable supplemental logging at the CDB level
-- ALTER SESSION SET CONTAINER=CDB$ROOT; 
-- ALTER DATABASE ADD SUPPLEMENTAL LOG DATA;
-- Enable Minimal supplemental logging at the CDB level again
ALTER SESSION SET CONTAINER=XEPDB1; 
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (ALL) COLUMNS;
exit;

-- # CREATING USERS FOR THE CONNECTOR
-- run if directory /opt/oracle/oradata/XEPDB/XEPDB1 doesn't exist
-- mkdir -p /opt/oracle/oradata/XEPDB/XEPDB1
-- sqlplus sys/password@localhost:1521/XEPDB1 as sysdba;

-- Creating the connector’s LogMiner user
-- sqlplus sys/top_secret@//localhost:1521/ORCLCDB as sysdba
--   CREATE TABLESPACE logminer_tbs DATAFILE '/opt/oracle/oradata/ORCLCDB/logminer_tbs.dbf'
--     SIZE 25M REUSE AUTOEXTEND ON MAXSIZE UNLIMITED;
--   exit;

-- sqlplus sys/top_secret@//localhost:1521/ORCLPDB1 as sysdba
--   CREATE TABLESPACE logminer_tbs DATAFILE '/opt/oracle/oradata/ORCLCDB/ORCLPDB1/logminer_tbs.dbf'
--     SIZE 25M REUSE AUTOEXTEND ON MAXSIZE UNLIMITED;
--   exit;
-- ALTER SESSION SET CONTAINER=XEPDB1; 

sqlplus sys/top_secret AS SYSDBA;
-- for root
ALTER SESSION SET CONTAINER=CDB$ROOT; 
CREATE TABLESPACE logminer_tbs DATAFILE '/opt/oracle/oradata/XEPDB/logminer_tbs.dbf' SIZE 25M REUSE AUTOEXTEND ON MAXSIZE UNLIMITED;

-- for PDB
-- mkdir -p /opt/oracle/oradata/XEPDB/XEPDB1
-- DROP TABLESPACE LOGMINER_TBS INCLUDING CONTENTS AND DATAFILES;
ALTER SESSION SET CONTAINER=XEPDB1;  
CREATE TABLESPACE logminer_tbs DATAFILE '/opt/oracle/oradata/XEPDB/XEPDB1/logminer_tbs.dbf' SIZE 25M REUSE AUTOEXTEND ON MAXSIZE UNLIMITED;

-- use c##<username> if you use oracle CBD (Container Database)
-- DROP TABLESPACE LOGMINER_TBS INCLUDING CONTENTS AND DATAFILES;
ALTER SESSION SET CONTAINER=CDB$ROOT; 
CREATE USER c##dbzuser IDENTIFIED BY dbz DEFAULT TABLESPACE logminer_tbs QUOTA UNLIMITED ON logminer_tbs CONTAINER=ALL;


GRANT CREATE SESSION TO c##dbzuser CONTAINER=ALL; 
GRANT SET CONTAINER TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$DATABASE to c##dbzuser CONTAINER=ALL; 
GRANT FLASHBACK ANY TABLE TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ANY TABLE TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT_CATALOG_ROLE TO c##dbzuser CONTAINER=ALL; 
GRANT EXECUTE_CATALOG_ROLE TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ANY TRANSACTION TO c##dbzuser CONTAINER=ALL; 
GRANT LOGMINING TO c##dbzuser CONTAINER=ALL; 
GRANT INSERT ANY TABLE TO c##dbzuser CONTAINER=ALL;



GRANT CREATE TABLE TO c##dbzuser CONTAINER=ALL; 
GRANT LOCK ANY TABLE TO c##dbzuser CONTAINER=ALL; 
GRANT CREATE SEQUENCE TO c##dbzuser CONTAINER=ALL; 


GRANT EXECUTE ON DBMS_LOGMNR TO c##dbzuser CONTAINER=ALL; 
GRANT EXECUTE ON DBMS_LOGMNR_D TO c##dbzuser CONTAINER=ALL;


GRANT SELECT ON V_$LOG TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$LOG_HISTORY TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$LOGMNR_LOGS TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$LOGMNR_CONTENTS TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$LOGMNR_PARAMETERS TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$LOGFILE TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$ARCHIVED_LOG TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$ARCHIVE_DEST_STATUS TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$TRANSACTION TO c##dbzuser CONTAINER=ALL; 


GRANT SELECT ON V_$MYSTAT TO c##dbzuser CONTAINER=ALL; 
GRANT SELECT ON V_$STATNAME TO c##dbzuser CONTAINER=ALL; 

exit;


-- -- Connect as a user with DBA privileges
-- sqlplus sys/password@localhost:1521/XEPDB1 as sysdba;
-- ALTER SESSION SET CONTAINER = CDB$ROOT; -- If necessary

-- -- Grant quota on the tablespace to the user
-- ALTER USER cdc_example QUOTA UNLIMITED ON USERS;

-- ALTER USER cdc_example QUOTA 100M ON USERS;

-- SELECT * FROM DBA_TS_QUOTAS WHERE USERNAME = 'C##DBZUSER' AND TABLESPACE_NAME = 'USERS';


-- Redo logs may be sized too small using the default mining strategy, consider increasing redo log sizes to a minimum of 500MB
-- ALTER SESSION SET CONTAINER=CDB$ROOT; 
-- SELECT group#, bytes/1024/1024 AS size_mb FROM v$log;
-- SELECT * FROM v$log;
-- SELECT group#, member FROM v$logfile;
-- ALTER DATABASE ADD LOGFILE GROUP 4 ('/opt/oracle/oradata/XE/redo01.log') SIZE 500M;
-- Untuk menghapus redo log group lama
-- ALTER DATABASE DROP LOGFILE GROUP 1;
-- SELECT group#, bytes/1024/1024 AS size_mb FROM v$log;


-- --no privileges on tablespace 'USERS'
-- SELECT * FROM DBA_TS_QUOTAS WHERE TABLESPACE_NAME = 'USERS';
-- -- if no rows
-- GRANT UNLIMITED TABLESPACE TO CDC_EXAMPLE;
-- ALTER USER CDC_EXAMPLE QUOTA UNLIMITED ON USERS;

-- SELECT TABLESPACE_NAME, STATUS FROM DBA_TABLESPACES WHERE TABLESPACE_NAME = 'USERS';
-- SELECT TABLESPACE_NAME, USED_SPACE, FREE_SPACE FROM DBA_FREE_SPACE WHERE TABLESPACE_NAME = 'USERS';

